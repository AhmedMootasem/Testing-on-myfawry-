
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium import webdriver
import time

driver = webdriver.Chrome('"C:\\Users\\Ahmed\\Downloads\\chromedriver_win32.zip"')  # Optional argument, if not specified will search path.

driver.get('https://www.fawry.com/jobs/')
search = driver.find_element(By.NAME, "search_location")
search = driver.find_element(By.NAME, "search_keywords")



search.send_keys("test")

search.send_keys(Keys.RETURN)

print(driver.page_source)

time.sleep(25)  # Let the user actually see something!

driver.quit()
